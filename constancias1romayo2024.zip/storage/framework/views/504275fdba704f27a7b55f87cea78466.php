

<?php $__env->startSection('title', 'Información'); ?>

<?php $__env->startSection('plugins.Datatables', true); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="mytitle">
        INFORMACIÓN DE <?php echo e($maestro->nombre); ?> 
        <?php echo e($maestro->apaterno); ?>

        <?php echo e($maestro->amaterno); ?>        
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <div class="card">
        <div class="card-body">
            <div class="row">
                <div class="form-group col-md-6">
                    <label for="region">REGIÓN</label>
                    <p id="region" class="with-border">
                        <?php echo e($maestro->delegacion->region->region); ?>&emsp;—&emsp; <?php echo e($maestro->delegacion->region->sede); ?> &nbsp;
                    </p>
                </div>
                <div class="form-group col-md-6">
                    <label for="delegacion">DELEGACIÓN</label>
                    <p id="delegacion" class="with-border">
                        <?php echo e($maestro->delegacion->delegacion); ?> <strong>/</strong>
                        <?php echo e($maestro->delegacion->nivel); ?> <strong>/</strong>
                        <?php echo e($maestro->delegacion->sede); ?> &nbsp;
                    </p>
                </div>
            </div>


            <div class="row">
                    <div class="form-group col-md-2">
                        <label for="nombre">GENERO</label>
                        <p id="genero" class="with-border"><?php echo e($maestro->genero->genero); ?> &nbsp; </p>
                    </div>
                    <div class="form-group col-md-4">
                        <label for="nombre">NOMBRE (S)</label>
                        <p id="nombre" class="with-border"><?php echo e($maestro->nombre); ?> &nbsp; </p>
                    </div>
                    <div class="form-group col-md-3">
                        <label for="apellido_paterno">APELLIDO PATERNO</label>
                        <p id="apellido_paterno" class="with-border"><?php echo e($maestro->apaterno); ?> &nbsp;</p>
                    </div>
                    <div class="form-group col-md-3">
                        <label for="apellido_materno">APELLIDO MATERNO</label>
                        <p id="apellido_materno" class="with-border"> <?php echo e($maestro->amaterno); ?> &nbsp;</p>
                    </div>                
            </div>

            <div class="row">
                    <div class="form-group col-md-3">
                        <label for="email">CORREO ELECTRÓNICO</label>
                        <p id="email" class="with-border"> <?php echo e($maestro->email); ?> &nbsp;</p>
                    </div>      
                    <div class="form-group col-md-3">
                        <label for="telefono">TELÉFONO</label>
                        <p id="telefono" class="with-border"> <?php echo e($maestro->telefono); ?> &nbsp;</p>
                    </div>
                    <div class="form-group col-md-3">
                        <label for="rfc">RFC</label>
                        <p id="rfc" class="with-border"> <?php echo e($maestro->rfc); ?> &nbsp;</p>
                    </div>     
                    <div class="form-group col-md-3">
                        <label for="numero_personal">NÚMERO DE PERSONAL</label>
                        <p id="numero_personal" class="with-border"> <?php echo e($maestro->npersonal); ?> &nbsp;</p>
                    </div>                                                                                     
            </div>

            <div class="form-group row">
                <label for="folio" class="col-md-2 col-form-label">FOLIO</label>
                <div class="col-md-10">
                    <p id="folio" class="with-border"><?php echo e($maestro->folio); ?></p>
                </div>
            </div>

            <div class="row justify-content-between" style="padding-right:7px">
                <a href="<?php echo e(route('maestro.index')); ?>" class="btn btn-secondary float-left ml-2">
                    <i class="fa fa-undo"></i>&emsp;Regresar
                </a>
                <a href="<?php echo e(route('maestro.edit', $maestro)); ?>" class="btn btn-success">
                    <i class="fa fa-pen"></i>&emsp;Editar usuario
                </a>                
            </div>














        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <style>
        .with-border {
            background-color: #F4F6F9;
            border: 1px solid #e6e6e6; 
            padding: 0.3em;
        }
        .mytitle {
            font-weight: bold;
            font-size: x-large;
            color: #ee7a00;
        }
    </style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\constancias1romayo2024\resources\views/maestros/show.blade.php ENDPATH**/ ?>