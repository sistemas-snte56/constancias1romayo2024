

<?php $__env->startSection('title', 'Consulta'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>CONSULTA TU CONSTANCIA</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="d-flex align-items-center justify-content-center" style="height: 70vh;"> <!-- Ajustamos la altura al 80% de la altura de la ventana -->
        <div class="card col-md-6" style="padding-top: 5em; padding-bottom: 5em;">
            <?php
                if (session()) {
                    if (session('message') == 'error') {
                        echo '<x-adminlte-alert theme="danger" title="Sin resultados">
                            No se encontró información
                            </x-adminlte-alert>
                        ';
                    }
                }
            ?>

            

            <blockquote class="blockquote mb-0 ">
                <p>Dudas o aclaraciones.</p>
                <footer class="blockquote-footer">Envíenos un correo a  <cite title="Correo electrónico">innovacion.tecnologica.snte56@gmail.com</cite></footer>
            </blockquote>

        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('css'); ?>
    
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php if(session('error')): ?>
        <script>
            $(document).ready(function(){
                let mensaje = "<?php echo e(session ('error')); ?>"
                Swal.fire({
                    //position: 'top-end',
                    icon: 'error',
                    title: mensaje,
                    text: "no hay resultados",
                    showConfirmButton: false,
                    showDenyButton: true,
                    denyButtonText: `Cerrar`
                });
            });
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\constancias1romayo2024\resources\views/consulta/busqueda.blade.php ENDPATH**/ ?>