

<?php $__env->startSection('title', 'Inicio'); ?>

<?php $__env->startSection('plugins.Datatables', true); ?>

<?php $__env->startSection('content_header'); ?>
    <div class="mytitle">
        ADMINISTRACIÓN DE USUARIO
    </div>    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $heads = [
            'ID',
            'REGIÓN',
            'DELEGACIÓN',
            'NOMBRE',
            // 'RFC',
            ['label' => 'NO. PERSONAL', 'width' => 10],
            'EMAIL',
            // 'TELÉFONO',
            ['label' => 'EDICION', 'no-export' => true, 'width' => 10]
        ];

        $btnDelete = '<button type="submit" class="btn btn-xs btn-default text-danger mx-1 shadow" title="Eliminar">
                            <i class="fa fa-lg fa-fw fa-trash"></i>
                        </button>';

        $config = [
            //'order' => [[1, 'asc']],
            //'columns' => [null, null, null, ['orderable' => false]],
            'columns' => [
                null,
                null,
                null,
                null,
                // ['orderable' => false],
                null,
                ['orderable' => false],
                // ['orderable' => false],                
                ['orderable' => false],                
            ],
            // 'language' => ['url' => '//cdn.datatables.net/plug-ins/2.0.5/i18n/es-ES.json']        
            'language' => ['url' => '//cdn.datatables.net/plug-ins/1.13.7/i18n/es-ES.json',],
            'lengthMenu' => [50,100,500],
            // 'order' => [[4, 'asc']],
            // 'searching' => true,
            // 'paging' => true,
            // 'info' => true,
        ];


    ?>

    <div class="card">
        <h5 class="card-header">LISTADO DE REGISTRO</h5>
        <div class="card-body">
            <h5 class="card-title">
                <a href="<?php echo e(route('maestro.import')); ?>" class="btn btn-success float-right">
                    <i class="fa fa-pen"></i>&emsp;Importar archivo
                </a>                

                <a href="<?php echo e(route('maestro.create')); ?>" class="btn btn-primary float-right mr-2">
                    <i class="fa fa-user"></i>&emsp;Nuevo usuario
                </a>

                <a href="<?php echo e(route('consulta.index')); ?>" class="btn btn-info float-right mr-2">
                    <i class="fa fa-file"></i>&emsp;Buscar constancia
                </a>


            </h5>
            <p class="card-text">
                
                <?php if (isset($component)) { $__componentOriginal1f0f987500f76b1f57bfad21f77af286 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f0f987500f76b1f57bfad21f77af286 = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Tool\Datatable::resolve(['id' => 'table1','heads' => $heads,'config' => $config,'striped' => true,'hoverable' => true,'withFooter' => true,'withButtons' => true,'bordered' => true] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-datatable'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Tool\Datatable::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                    <?php $contador = 1; ?>
                    <?php $__currentLoopData = $maestros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $maestro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($contador++); ?></td>
                            <td><?php echo e($maestro->delegacion->region->region); ?>&emsp;—&emsp; <?php echo e($maestro->delegacion->region->sede); ?></td>
                            <td><?php echo e($maestro->delegacion->delegacion); ?> 
                            <td><?php echo e($maestro->nombre); ?> 
                                <?php echo e($maestro->apaterno); ?>

                                <?php echo e($maestro->amaterno); ?>

                            
                            <td><?php echo e($maestro->npersonal); ?></td>
                            <td><?php echo e($maestro->email); ?></td>
                            
                            
                            <td>
                                <a href="<?php echo e(route('maestro.show', $maestro)); ?>" class="btn btn-xs btn-default text-teal mx-1 shadow" title="Mostrar">
                                    <i class="fa fa-lg fa-fw fa-eye"></i>
                                </a>                            
                                <a href="<?php echo e(route('maestro.edit',$maestro)); ?>" class="btn btn-xs btn-default text-primary mx-1 shadow" title="Editar">
                                    <i class="fa fa-lg fa-fw fa-pen"></i>
                                </a>
                                <form action="<?php echo e(route('maestro.destroy',$maestro)); ?>" method="post" class="formEliminar" style="display: inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo $btnDelete; ?>

                                </form>
                                <a href="<?php echo e(route('generar.pdf', $maestro->codigo_id)); ?>" target="_blank" class="btn btn-xs buttons-print btn-default  mx-1 " title="Imprimir hoja">
                                    <i class="fas fa-fw fa-lg fa-print"></i>
                                </a>  
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f0f987500f76b1f57bfad21f77af286)): ?>
<?php $attributes = $__attributesOriginal1f0f987500f76b1f57bfad21f77af286; ?>
<?php unset($__attributesOriginal1f0f987500f76b1f57bfad21f77af286); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f0f987500f76b1f57bfad21f77af286)): ?>
<?php $component = $__componentOriginal1f0f987500f76b1f57bfad21f77af286; ?>
<?php unset($__componentOriginal1f0f987500f76b1f57bfad21f77af286); ?>
<?php endif; ?>
            </p>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<style>
    .mytitle {
        font-weight: bold;
        font-size: x-large;
        color: #ee7a00;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function() {
            $('.formEliminar').submit(function(e) {
                e.preventDefault();
                Swal.fire({
                    title: "Estas seguro?",
                    text: "¡No podrás revertir esto!",
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#3085d6",
                    cancelButtonColor: "#d33",
                    confirmButtonText: "Si, borrarlo!"
                }).then((result) => {
                    if (result.isConfirmed) {
                        if (result.isConfirmed) {
                            this.submit();
                        }
                    }
                });
            })
        });
    </script>

delete_ok




    <?php if(session('delete_ok')): ?>
        <script>
            $(document).ready(function(){
                let mensaje = "<?php echo e(session ('delete_ok')); ?>"
                Swal.fire({
                    title: "¡Eliminado!",
                    text: mensaje,
                    icon: 'success',
                });
            });
        </script>
    <?php endif; ?>



    <?php if(session('success')): ?>
        <script>
            $(document).ready(function(){
                let mensaje = "<?php echo e(session ('success')); ?>"
                Swal.fire({
                    icon: 'success',
                    title: mensaje,
                });
            });
        </script>
    <?php endif; ?>
    <?php if(session('status')): ?>
        <script>
            $(document).ready(function(){
                let mensaje = "<?php echo e(session ('status')); ?>"
                Swal.fire({
                    icon: 'success',
                    title: mensaje,
                    // text: "no hay resultados",
                    showConfirmButton: false,
                    showDenyButton: true,
                    confirmButtonText: `Cerrar`
                });
            });
        </script>
    <?php endif; ?>
    <?php if(session('update_ok')): ?>
        <script>
            $(document).ready(function(){
                let mensaje = "<?php echo e(session ('update_ok')); ?>"
                Swal.fire({
                    title: mensaje,
                    //text: "Your file has been deleted.",
                    icon: "success"
                });                

            });
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\constancias1romayo2024\resources\views/maestros/index.blade.php ENDPATH**/ ?>