

<?php $__env->startSection('title', 'Importa'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>IMPORTAR TU ARCHIVO</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="d-flex align-items-center justify-content-center" style="height: 70vh;"> <!-- Ajustamos la altura al 80% de la altura de la ventana -->
        <div class="card col-md-6" style="padding-top: 5em; padding-bottom: 5em;">
            <div class="card-body">
                <form action="<?php echo e(route('maestro.import')); ?>" method="post" enctype="multipart/form-data" >
                    <?php echo csrf_field(); ?>
                    
                    <?php if (isset($component)) { $__componentOriginalc49abe9ea9cb5496814d5780e6ddffe2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc49abe9ea9cb5496814d5780e6ddffe2 = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\InputFile::resolve(['id' => 'importar_archivo','name' => 'importar_archivo','label' => 'Upload files','igroupSize' => 'lg','legend' => 'Buscar'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-input-file'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\InputFile::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                         <?php $__env->slot('appendSlot', null, []); ?> 
                            <?php if (isset($component)) { $__componentOriginal84b78d66d5203b43b9d8c22236838526 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal84b78d66d5203b43b9d8c22236838526 = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Form\Button::resolve(['theme' => 'primary','label' => 'Cargar','type' => 'submit'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Form\Button::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal84b78d66d5203b43b9d8c22236838526)): ?>
<?php $attributes = $__attributesOriginal84b78d66d5203b43b9d8c22236838526; ?>
<?php unset($__attributesOriginal84b78d66d5203b43b9d8c22236838526); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal84b78d66d5203b43b9d8c22236838526)): ?>
<?php $component = $__componentOriginal84b78d66d5203b43b9d8c22236838526; ?>
<?php unset($__componentOriginal84b78d66d5203b43b9d8c22236838526); ?>
<?php endif; ?>
                         <?php $__env->endSlot(); ?>
                         <?php $__env->slot('prependSlot', null, []); ?> 
                            <div class="input-group-text text-primary">
                                <i class="fas fa-file-upload"></i>
                            </div>
                         <?php $__env->endSlot(); ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc49abe9ea9cb5496814d5780e6ddffe2)): ?>
<?php $attributes = $__attributesOriginalc49abe9ea9cb5496814d5780e6ddffe2; ?>
<?php unset($__attributesOriginalc49abe9ea9cb5496814d5780e6ddffe2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc49abe9ea9cb5496814d5780e6ddffe2)): ?>
<?php $component = $__componentOriginalc49abe9ea9cb5496814d5780e6ddffe2; ?>
<?php unset($__componentOriginalc49abe9ea9cb5496814d5780e6ddffe2); ?>
<?php endif; ?>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('css'); ?>
    
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <?php if(session('error_status')): ?>
        <script>
            $(document).ready(function(){
                let mensaje = "<?php echo e(session ('error_status')); ?>"
                Swal.fire({
                    icon: 'error',
                    title: mensaje,
                    // text: "no hay resultados",
                    showConfirmButton: false,
                    showDenyButton: true,
                    confirmButtonText: `Cerrar`
                });
            });
        </script>
    <?php endif; ?>
    <?php if(session('error_upload')): ?>
        <script>
            $(document).ready(function(){
                let mensaje = "<?php echo e(session ('error_status')); ?>"
                Swal.fire({
                    icon: 'error',
                    title: mensaje,
                    // text: "no hay resultados",
                    showConfirmButton: false,
                    showDenyButton: true,
                    confirmButtonText: `Cerrar`
                });
            });
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\constancias1romayo2024\resources\views/maestros/import.blade.php ENDPATH**/ ?>