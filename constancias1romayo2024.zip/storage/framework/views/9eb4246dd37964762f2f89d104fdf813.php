


<?php $__env->startSection('title', 'Consulta'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>RESULTADOS DE BUSQUEDA</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-body">

            <?php
                $heads = [
                    'ID',
                    'REGIÓN',
                    'DELEGACIÓN',
                    'NOMBRE',
                    // 'APELLIDOS',
                    ['label' => 'IMPRESION', 'no-export' => true, 'width' => 10],
                ];

                $btnEdit = '<button class="btn btn-xs btn-default text-primary mx-1 shadow" title="Edit">
                                <i class="fa fa-lg fa-fw fa-pen"></i>
                            </button>';
                $btnDelete = '<button class="btn btn-xs btn-default text-danger mx-1 shadow" title="Delete">
                                <i class="fa fa-lg fa-fw fa-trash"></i>
                            </button>';
                $btnDetails = '<button class="btn btn-xs btn-default text-teal mx-1 shadow" title="Details">
                                <i class="fa fa-lg fa-fw fa-eye"></i>
                            </button>';

                $config = [
                    'order' => [[1, 'asc']],
                    'columns' => [null, null, null, ['orderable' => false]],
                    'language' => [
                            'url' => '//cdn.datatables.net/plug-ins/2.0.5/i18n/es-ES.json',
                        ],
                    'paging' => false,
                    'lengthMenu' => false,
                    'searching' => false,
                    'info' => false,
                ];
            ?>

            
            <?php if (isset($component)) { $__componentOriginal1f0f987500f76b1f57bfad21f77af286 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1f0f987500f76b1f57bfad21f77af286 = $attributes; } ?>
<?php $component = JeroenNoten\LaravelAdminLte\View\Components\Tool\Datatable::resolve(['id' => 'table1','heads' => $heads] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('adminlte-datatable'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(JeroenNoten\LaravelAdminLte\View\Components\Tool\Datatable::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['style' => 'width: 70%;']); ?>
                <?php $contador = 1; ?>
                <?php $__currentLoopData = $maestros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $maestro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr style="text-transform: uppercase;">
                        <td><?php echo e($contador++); ?></td>
                        <td><?php echo e($maestro->delegacion->region->region); ?> - <?php echo e($maestro->delegacion->region->sede); ?></td>
                        <td><?php echo e($maestro->delegacion->delegacion); ?>&nbsp;<?php echo e($maestro->delegacion->nivel); ?>&nbsp;<?php echo e($maestro->delegacion->sede); ?></td>
                        <td><?php echo e($maestro->nombre); ?> <?php echo e($maestro->apaterno); ?> <?php echo e($maestro->amaterno); ?></td>
                        <td> 
                            <a href="<?php echo e(route('generar.pdf', $maestro->codigo_id)); ?>" target="_blank" class="btn btn-sm buttons-print btn-success mx-1 " title="Imprimir hoja">
                                <i class="fas fa-fw fa-lg fa-print"></i> IMPRIMIR
                            </a>                             
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1f0f987500f76b1f57bfad21f77af286)): ?>
<?php $attributes = $__attributesOriginal1f0f987500f76b1f57bfad21f77af286; ?>
<?php unset($__attributesOriginal1f0f987500f76b1f57bfad21f77af286); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f0f987500f76b1f57bfad21f77af286)): ?>
<?php $component = $__componentOriginal1f0f987500f76b1f57bfad21f77af286; ?>
<?php unset($__componentOriginal1f0f987500f76b1f57bfad21f77af286); ?>
<?php endif; ?>

            <center>
                <div class="row">
                    <div class="form-group">
                        <a href="<?php echo e(route('consulta.store')); ?>" class="btn btn-secondary mx-2 shadow" title="Delete">
                            <i class="fa fa-lg fa-fw fa-undo"></i> Regresar
                        </a >

                    </div>
                </div>
            </center>


            <blockquote class="blockquote mb-0">
                <p>Dudas o aclaraciones.</p>
                <footer class="blockquote-footer">Envíenos un correo a  <cite title="Correo electrónico">innovacion.tecnologica.snte56@gmail.com</cite></footer>
            </blockquote>



        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\constancias1romayo2024\resources\views/consulta/resultado.blade.php ENDPATH**/ ?>